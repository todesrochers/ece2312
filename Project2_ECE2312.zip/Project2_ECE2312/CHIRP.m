function [] = CHIRP()
   Fs = 44100;                  % samples per second

   % create time signal
tStart = 0;
tEnd = 5;
t = tStart:1/Fs:tEnd;
% create swept sine
f0 = 0;
f = 8000;
%phaseInit = -90;
method = 'linear';
x = chirp(t, f0, tEnd, f, method);

   % Plot the signal versus time:
   figure;
   plot(t,x);
   xlabel('time (in seconds)');
   title('Chirp Signal versus Time');

   sound(x,Fs)
   
   %saving to WAV file
   audiowrite("Team3-chirp.wav", x, Fs);
   clear x Fs;
   audioinfo("Team3-chirp.wav")
   [x,Fs] = audioread('Team3-chirp.wav');
   
  %sample code from project description
  x1 = x(:,1);
  window = hamming(512);
  N_overlap = 256;
  N_fft = 1024;
  [S,F,T,P] = spectrogram(x1, window, N_overlap, N_fft, Fs,'yaxis');

  figure;
  surf(T,F,10*log10(P), 'edgecolor', 'none');
  axis tight;
  view(0,90);   
  colormap(jet);
  set(gca,'clim', [-80,-20]);
  ylim([0 8000]);
  xlabel('Time (s)'); 
  ylabel('Frequency (Hz)');
  title('Chirp Signal versus Time');

end