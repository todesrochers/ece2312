function [] = StereoFun(y, fs, Z)
[y,fs] = audioread('BrownFox.wav');
length(y); %44100*5 = 220500
y1 = y(:,1);
%vec_brown = zeros(length(y1),1);

[y,fs] = audioread('Team3-speechchirp.wav');
y2 = y(:,1);
%vec_sine = zeros(length(y2),1);

NewOutput = cat(2,y1,y2);

%saving to WAV file
audiowrite("Team3-stereospeechsine.wav", NewOutput, fs);

sound(NewOutput,fs)
end