function [] = StereoFun(y, fs, Z)
[y,fs] = audioread('BrownFox.wav');
length(y); %44100*5 = 220500
y1 = y(:,1);
%vec_brown = zeros(length(y1),1);

[y,fs] = audioread('Team3-speechchirp.wav');
y2 = y(:,1);
%vec_sine = zeros(length(y2),1);

NewOutput = cat(2,y1,y2);

%saving to WAV file
audiowrite("Team3-stereospeechsine.wav", NewOutput, fs);

sound(NewOutput,fs)

%sample code from project description
window = hamming(512);
N_overlap = 256;
N_fft = 1024;
[S,F,T,P] = spectrogram(y1, window, N_overlap, N_fft, fs,'yaxis');

figure;
surf(T,F,10*log10(P), 'edgecolor', 'none');
axis tight;
view(0,90);
colormap(jet);
set(gca,'clim', [-80,-20]);
ylim([0 8000]);
xlabel('Time (s)'); ylabel('Frequency (Hz)');
title('Left Side Audio: Frequency(Hz) vs. Time(s)')

%sample code from project description
window = hamming(512);
N_overlap = 256;
N_fft = 1024;
[S,F,T,P] = spectrogram(y2, window, N_overlap, N_fft, fs,'yaxis');

figure;
surf(T,F,10*log10(P), 'edgecolor', 'none');
axis tight;
view(0,90);
colormap(jet);
set(gca,'clim', [-80,-20]);
ylim([0 8000]);
xlabel('Time (s)'); ylabel('Frequency (Hz)');
title('Right Side Audio: Frequency(Hz) vs. Time(s)')
end