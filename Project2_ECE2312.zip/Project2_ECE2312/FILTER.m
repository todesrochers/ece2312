function [] = FILTER()
    comread = audioread("Team3-speechchirp.wav");
     f = 0:1/22050:1;   %[0 0.4 0.6 1];
     f = f(1:length(f)-1);
     fc = 4000;
     a = cat(1, zeros(fc, 1), ones(22050-fc, 1));
     a = a(:,1);
     n = 1;
     Fs = 44100;

    b = firls(n, f, a);
    a1 = ones(1, 1);
%     x = filter(b, a1, comread);
   % x = fft(comread(:, 1))*fft(b);

%     x = fft(x);
    
 
    %g = comread + filter;
    x = lowpass(comread(:,1),1900, Fs);

    sound(x, Fs)
%saving to WAV file
   audiowrite("Team3-filteredspeechsine.wav", x, Fs);
  % clear x Fs;
   audioinfo("Team3-filteredspeechsine.wav")
%    [x,Fs] = audioread('Team3-filteredspeechsine.wav');
%    
  %sample code from project description
  x1 = x(:,1);
  window = hamming(512);
  N_overlap = 256;
  N_fft = 1024;
  [S,F,T,P] = spectrogram(x1, window, N_overlap, N_fft, Fs,'yaxis');

  figure;
  surf(T,F,10*log10(P), 'edgecolor', 'none');
  axis tight;
  view(0,90);   
  colormap(jet);
  set(gca,'clim', [-80,-20]);
  ylim([0 8000]);
  xlabel('Time (s)'); 
  ylabel('Frequency (Hz)');
  title('Combining Sound Files') 
end



