function [] = FILTER()
    comread = audioread("Team3-speechchirp.wav");
     f = [0 0.45 0.55 1];
     a = [1 1 0 0];
     n = 1;
     Fs = 44100;
 
     filter = firls(n, f, a);

    %g = comread + filter;

    x = lowpass(comread,4000)

    sound(x, Fs)
 %saving to WAV file
   audiowrite("Team3-filteredspeechsine.wav", x, Fs);
   clear x Fs;
   audioinfo("Team3-filteredspeechsine.wav")
   [x,Fs] = audioread('Team3-filteredspeechsine.wav');
   
  %sample code from project description
  x1 = x(:,1);
  window = hamming(512);
  N_overlap = 256;
  N_fft = 1024;
  [S,F,T,P] = spectrogram(x1, window, N_overlap, N_fft, Fs,'yaxis');

  figure;
  surf(T,F,10*log10(P), 'edgecolor', 'none');
  axis tight;
  view(0,90);   
  colormap(jet);
  set(gca,'clim', [-80,-20]);
  ylim([0 8000]);
  xlabel('Time (s)'); 
  ylabel('Frequency (Hz)');
  title('Combining Sound Files') 
end

