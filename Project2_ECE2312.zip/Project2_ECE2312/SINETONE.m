
   Fs = 44100;                   % samples per second
   dt = 1/Fs;                   % seconds per sample
   StopTime = 5;             % seconds
   t = (0:dt:StopTime-dt)';     % seconds
   %%Sine wave:
   Fc = 5000;                     % hertz
   x = sin(2*pi*Fc*t);
   % Plot the signal versus time:
   figure;
   plot(t,x);
   xlabel('time (in seconds)');
   title('Signal versus Time');

   sound(x,Fs)
   %saving to WAV file
   audiowrite("Team3_sinetone.wav", x, Fs);
   clear x Fs;
   audioinfo("Team3_sinetone.wav")
   [x,Fs] = audioread('Project1WAV.wav');
