function [] = COMBINE()
s1 = audioread("BrownFox.wav");
s2= audioread("Team3-sinetone.wav");
Fs = 44100;

audioinfo("BrownFox.wav")
audioinfo("Team3-sinetone.wav")

x=s1+s2;

sound(x, Fs)
 %saving to WAV file
   audiowrite("Team3-speechchirp.wav", x, Fs);
   clear x Fs;
   audioinfo("Team3-speechchirp.wav")
   [x,Fs] = audioread('Team3-speechchirp.wav');
   
  %sample code from project description
  x1 = x(:,1);
  window = hamming(512);
  N_overlap = 256;
  N_fft = 1024;
  [S,F,T,P] = spectrogram(x1, window, N_overlap, N_fft, Fs,'yaxis');

  figure;
  surf(T,F,10*log10(P), 'edgecolor', 'none');
  axis tight;
  view(0,90);   
  colormap(jet);
  set(gca,'clim', [-80,-20]);
  ylim([0 8000]);
  xlabel('Time (s)'); 
  ylabel('Frequency (Hz)');
  title('Combining Sound Files')
end
