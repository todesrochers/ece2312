function [] = FUNSINETONE()
   Fs = 44100;                  % samples per second
   dt = 1/Fs;                   % seconds per sample
   StopTime = 5;                % seconds
   t = (0:dt:StopTime)';     % seconds
   
   %t1=0:0.1:0.5;
   f1=7500;
   %t2=0.5:0.1:1.25;
   f2=6500;
   %t3=1.25:0.1:2.25;
   f3=5200;
   %t4=2.25:0.1:3;
   f4=1800;
   %t5=3:0.1:5;
   f5=1200;

   if (t<0.5)
       Fc = f1;
   else if (t>0.5 && t<1.25)
       Fc = f2;
   else if (t>1.25 && t<2.25)
       Fc = f3;
   else if (t>2.25 && t<3)
       Fc = f4;
   else Fc = f5;
   end
   end
   end
   end
   
   %%Sine wave:
   wo = 2*pi*Fc;
   x = sin(wo*t);
   % Plot the signal versus time:
   figure;
   plot(t,x);
   xlabel('time (in seconds)');
   title('Signal versus Time');

   sound(x,Fs)
   
   %saving to WAV file
   audiowrite("Team3-sinetone.wav", x, Fs);
   clear x Fs;
   audioinfo("Team3-sinetone.wav")
   [x,Fs] = audioread('Team3-sinetone.wav');
   
  %sample code from project description
  x1 = x(:,1);
  window = hamming(512);
  N_overlap = 256;
  N_fft = 1024;
  [S,F,T,P] = spectrogram(x1, window, N_overlap, N_fft, Fs,'yaxis');

  figure;
  surf(T,F,10*log10(P), 'edgecolor', 'none');
  axis tight;
  view(0,90);   
  colormap(jet);
  set(gca,'clim', [-80,-20]);
  ylim([0 8000]);
  xlabel('Time (s)'); 
  ylabel('Frequency (Hz)');
end
