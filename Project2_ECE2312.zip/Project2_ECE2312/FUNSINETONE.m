function [] = FUNSINETONE()
   Fs = 44100;                  % samples per second
   dt = 1/Fs;                   % seconds per sample
   StopTime = 5;                % seconds
   t = (0:dt:StopTime)';     % seconds
   
   %t1=0:0.1:0.5;
   f1=7500;
   %t2=0.5:0.1:1.25;
   f2=6500;
   %t3=1.25:0.1:2.25;
   f3=5200;
   %t4=2.25:0.1:3;
   f4=1800;
   %t5=3:0.1:5;
   f5=1200;
%    for i = 1:length(t)
%         t1 = t(i);
%         t1
%         if (t1<0.5)
%            Fc = f1;
%        elseif (t1>=0.5 && t1<1.25)
%            Fc = f2;
%        elseif (t1>=1.25 && t1<2.25)
%            Fc = f3;
%        elseif (t1>=2.25 && t1<3)
%            Fc = f4;
%        else 
%            Fc = f5;
%        end
%    
%         wo = 2*pi*Fc;
%           
%        %%Sine wave:
%        if i == 1
%            x = sin(wo*t);  
%        else
%         x = cat(1, x, sin(wo*t));
%        end
%    end
%    

   Fc_all = [f1, f2, f3, f4, f5];
   t_all = [0, 0.5, 1.25, 2.25, 3, 5];
   for i = 1:length(t_all)-1
       i
    del_t = t_all(i):1/Fs:t_all(i+1);
    wo = 2*pi*Fc_all(i);
    if i == 1
        x = sin(wo*del_t);
    else
%         length(x)
%         length (sin(wo*del_t))
        x = cat(2, x, sin(wo*del_t));
    end
    length(x)
   end
   length(x)
   length(t)
   % Plot the signal versus time:
   figure;
   plot(x);
   xlabel('time (in seconds)');
   title('Signal versus Time');

   sound(x,Fs)
   
   %saving to WAV file
   audiowrite("Team3-sinetone.wav", x, Fs);
   clear x Fs;
   audioinfo("Team3-sinetone.wav")
   [x,Fs] = audioread('Team3-sinetone.wav');
   
  %sample code from project description
  x1 = x(:,1);
  window = hamming(512);
  N_overlap = 256;
  N_fft = 1024;
  [S,F,T,P] = spectrogram(x1, window, N_overlap, N_fft, Fs,'yaxis');

  figure;
  surf(T,F,10*log10(P), 'edgecolor', 'none');
  axis tight;
  view(0,90);   
  colormap(jet);
  set(gca,'clim', [-80,-20]);
  ylim([0 8000]);
  xlabel('Time (s)'); 
  ylabel('Frequency (Hz)');
end
