function [] = AllFunctionsProject3()
    DOWNSAMPLE()
    HIGH()
    LOW()
    REASSEMBLE()
end